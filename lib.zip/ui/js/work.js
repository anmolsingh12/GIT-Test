var obj;

function getWorkItem(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/workitem/all", "true");
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log("Display Name :"+this.responseText);
             obj = JSON.parse(this.responseText);
            console.log(obj);
            showTable();
		}
	}; 
}

function showTable(){
    for(var i=0; i<obj.length; i++)
    {
        var tr="<tr>";
        var td1="<td>"+obj[i].Id+"</td>";
        var td2="<td>"+obj[i].Name+"</td>";
        var td3="<td>"+obj[i].Type+"</td>";
        var td4="<td>"+obj[i].Requester+"</td>";
        var td5="<td>"+obj[i].Owner+"</td>";
        var td6="<td>"+obj[i].Created+"</td></tr>";

       $("#mytable").append(tr+td1+td2+td3+td4+td5+td6); 

    }  
}