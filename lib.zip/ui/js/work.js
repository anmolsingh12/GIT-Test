var obj;

function getWorkItem(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/workitem/all", "true");
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
            console.log("Display Name :"+this.responseText);
            var ob = JSON.parse(this.responseText);

            if(ob.length == 0)
            {
                document.getElementById("res").innerHTML = "No Records Found.";
            }
            else
            {
                obj = ob;
                console.log(obj);
                showTable();
            }
		}
	}; 
}

function showTable(){
    for(var i=0; i<obj.length; i++)
    {
        var tr='<tr>';
        var chk = '<td><input class="check" onclick="displayId(`check`)" type="checkbox" name="check'+i+'" value="'+obj[i].Id+'"/></td>';
        var td1 = '<td id="id'+i+'">'+obj[i].Id+'</td>';
        var td2 = '<td id="name'+i+'">'+obj[i].Name+'</td>';
        var td3 = '<td id="type'+i+'">'+obj[i].Type+'</td>';
        var td4 = '<td id="requester'+i+'">'+obj[i].Requester+'</td>';
        var td5 = '<td id="owner'+i+'">'+obj[i].Owner+'</td>';
        var td6 = '<td id="date'+i+'">'+obj[i].Created+'</td></tr>';

       $("#mytable").append(tr+chk+td1+td2+td3+td4+td5+td6); 

    }  
}

var cboxes;

function displayId(className)
{
    cboxes = document.getElementsByClassName(className);

    var len = cboxes.length;
    for (var i=0; i<len; i++) 
    {
        if(cboxes[i].checked)
        {
            checkOne(cboxes, i);
            
            // if(cboxes[0].checked)
            // {
            //     checkAll(cboxes);
            // }
            console.log(i + ' checked '+ cboxes[i].value);
            
        }
        else if(!cboxes[i].checked)
        {
            unCheckOne(cboxes, i);

            // if(!cboxes[0].checked)
            // {
            //     uncheckAll(cboxes);
            // }
            console.log(i + ' unchecked '+ cboxes[i].value);   
        }
    }
        
    // if(cboxes[0].checked)
    // {
    //     checkAll(cboxes);
    // }

    // else if(!cboxes[0].checked)
    // {
    //     uncheckAll(cboxes);
    // }
}

function checkAll(cboxes)
{
    for(var i = 1; i < cboxes.length; i++)
    {
        cboxes[i].checked = true;
    }
}

function uncheckAll(cboxes)
{
    for(var i = 1; i < cboxes.length; i++)
    {
        cboxes[i].checked = false;
    }
}

function checkOne(cboxes, i)
{
    cboxes[i].checked = true;
}

function unCheckOne(cboxes, i)
{
    cboxes[i].checked = false;
}