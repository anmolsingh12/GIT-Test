function changeCmntValue(id)
{
	var cmntBox = document.getElementById(id);
	var cmnt = cmntBox.value;
	var idVal = id.substring(4);
	selectedWorkItems.set(idVal,cmnt);
}

function checkState(id)
{
	if(id == "All")
	{
		var cmntBox = document.getElementsByClassName('cmnt');
        var cAllbox = document.getElementById(id);

		if(cAllbox.checked)
		{
			var cboxes = document.getElementsByClassName('check');
			checkAll(cboxes);
			
			if(selectedWorkItems.size > 0)
			{
				//console.log("Array has values")
				
				selectedWorkItems.clear();
				

				for(var k = 0; k < cboxes.length; k++ )
				{
					//console.log(cboxes[k].value.toString())
					selectedWorkItems.set(cboxes[k].value.toString(), cmntBox[k].value ); 
				}

			}
			else
			{
				for(var k = 0; k < cboxes.length; k++ )
				{
					selectedWorkItems.set(cboxes[k].value.toString(), cmntBox[k].value ); 
				}
			}			
		}

		if(!cAllbox.checked)
		{
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			selectedWorkItems.clear();
			//console.log(' unchecked '+ cAllbox.value);  
		}
	}

	else
	{
		var cAllb = document.getElementById('All'); 
		var checkbox = document.getElementById(id);

		 if(cAllb.checked)
            cAllb.checked =  false;

		if(checkbox.checked)
		{
			jQuery('#cmnt'+checkbox.value).removeAttr("disabled");
			//console.log({id : checkbox.value.toString(), comment : jQuery('#cmnt'+checkbox.value)[0].value });
			selectedWorkItems.set(checkbox.value.toString(), jQuery('#cmnt'+checkbox.value)[0].value );
			jQuery('#error-text').css('visibility', 'hidden');
			jQuery('#error-text').removeClass("formWarn"); 
			jQuery('#error-text')[0].innerHTML = "";
		}

		else
		{
			jQuery('#cmnt'+checkbox.value).attr("disabled", "disabled");
			//console.log({id : checkbox.value.toString(), comment : jQuery('#cmnt'+checkbox.value)[0].value });
			selectedWorkItems.delete(checkbox.value.toString());
		}
	}
}

function checkAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		//console.log(cboxes[i].value);
		jQuery('#cmnt'+cboxes[i].value).removeAttr('disabled');
        cboxes[i].checked = true;
    }
}

function uncheckAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		jQuery('#cmnt'+cboxes[i].value).attr("disabled", "disabled");
        cboxes[i].checked = false;
    }
}

function changePageOnText(event)
{
	if (event.keyCode === 13) 
	{
		event.preventDefault();
		var pageCount1 = jQuery("#pageCount").val();
		var regex = '/^[0-9]*$/';
		valueValid = false;

		for(var i = 0; i < pageCount1.toString().length; i++)
		{
			if(pageCount1.toString().charCodeAt(i) <= 57 && pageCount1.toString().charCodeAt(i) >= 49)
			{
				valueValid = true;
			}
			else
			{
				valueValid = false;
				break;
			}
		}

		if(valueValid == true && pageCount1 <= pg2)
		{
			jQuery(".post").remove();
			jQuery("#table1").remove();
			getData(workitemsPerPage,pageCount1);
		}
	}
}				
	
function goRight(){
	var pageCount1=jQuery("#pageCount").val();
	if(pageCount1<pg2)
	{
		pageCount1++; 
	}
	jQuery("#table1").remove();
	getData(workitemsPerPage,pageCount1);
}

function goLeft(){
	var pageCount1=jQuery("#pageCount").val();
	if(pageCount1>1)
	{
		pageCount1--;
	}
	jQuery("#table1").remove();
	getData(workitemsPerPage,pageCount1);
}

function goBackward(){
	document.getElementById("pageCount").value = 1;
	jQuery("#table1").remove();
	getData(workitemsPerPage,1);
}

function goForward(){
	document.getElementById("pageCount").value = pg2;
	jQuery("#table1").remove();
	getData(workitemsPerPage,pg2);
}

function doRefresh(){
	var pageCount1=jQuery("#pageCount").val();
	jQuery("#table1").remove();
	getData(workitemsPerPage,pageCount1);
}
