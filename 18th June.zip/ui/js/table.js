function loadData()
{
	console.log("Inside loaddata()")
	if(jQuery('#pgSpan').innerHTML != '')
	{
		console.log("Calling Show Table")
		myVar = setTimeout(showTable, 1500);
		jQuery('#error-text').css('visibility', 'hidden');
		jQuery('#error-text').removeClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "";
	}
}

function showTable() {
	console.log("Inside showtable()")
	document.getElementById("loader").style.display = "none";
	jQuery('#All')[0].checked = false;
	jQuery('#item_table').css("visibility","visible");
	jQuery('#reject').css("visibility","visible");
	jQuery('#approve').css("visibility","visible"); 
	jQuery('#com-cmnt').css("visibility", "visible")
	jQuery('#btn-grp').css("visibility", "visible")

	var html = '<tbody id="table1" style="background-color:##E5E8E8">';
	for (var i=0; i<obj.length; i++) {
		// console.log(obj[i]);
		html += '<tr class="post" title="'+obj[i].Description+'">';
		//console.log(obj[i].Description);
		html += '<td style="width:3%;" ><input class="check" type="checkbox" id="check'+obj[i].Name+'" value="'+obj[i].Name+'" onclick="checkState(this.id)"/></td>';
		html +=	'<td style="width:3%;">'+ obj[i].Name +'</td>';
		html +=	'<td style="width:9%;">' + obj[i].Requestee + '</td>';
		html += '<td style="width:8%;">' + obj[i].Requester + '</td>';
		html +=	'<td style="width:20%;">' + obj[i].Operation + '</td>';
		//console.log(obj[i].Operation);
		html += '<td style="width:9%;">' + obj[i].Application + '</td>';
		html += '<td style="width:9%;">' + obj[i].Created + '</td>';
		html += '<td style="width:10%;"><input disabled="disabled" type="text" class="cmnt" oninput="changeCmntValue(this.id)" id="cmnt'+obj[i].Name+'"/></td>';						
		html += "</tr>";
	}
	html += '</tbody>';
	jQuery(html).appendTo('#item_table');
	jQuery('#bottom-display')[0].innerHTML = 'Displaying '+obj[0].No+' - '+obj[obj.length-1].No+' of '+totalWorkitems;

	 for (var i=0; i<obj.length; i++) {
	 	if(selectedWorkItems.has(obj[i].Name))
	 	{
	 		var obj_id = '#check'+obj[i].Name;
	 		jQuery(obj_id)[0].checked = true;
	 		jQuery('#cmnt'+obj[i].Name).removeAttr('disabled');
	 	}
	}

	jQuery('#backward').attr("disabled", "disabled");
	jQuery('#left').attr("disabled", "disabled");

	var totalPages=document.getElementById('pgSpan').innerHTML;
	console.log(totalPages);
	var currentPage = document.getElementById('pageCount').value;
	console.log(currentPage)

	if(currentPage == totalPages)
	{
		console.log("Not Possible value")
		if(currentPage == 1)
		{
			jQuery('#forward').attr("disabled", "disabled");
			jQuery('#right').attr("disabled", "disabled");
			jQuery('#backward').attr("disabled", "disabled");
			jQuery('#left').attr("disabled", "disabled");
		}
		else
		{
			jQuery('#forward').attr("disabled", "disabled");
			jQuery('#right').attr("disabled", "disabled");
			jQuery('#backward').removeAttr("disabled");
			jQuery('#left').removeAttr("disabled");
		}
	}

	else
	{
		console.log("Possible value")
		if(currentPage != 1)
		{
			jQuery('#backward').removeAttr("disabled");
			jQuery('#left').removeAttr("disabled");
			jQuery('#forward').removeAttr("disabled");
			jQuery('#right').removeAttr("disabled");
		}
		else
		{
			jQuery('#backward').attr("disabled", "disabled");
			jQuery('#left').attr("disabled", "disabled");
			jQuery('#forward').removeAttr("disabled");
			jQuery('#right').removeAttr("disabled");
		}
	}
}