var obj;
var resultObject;
var pg;
var totalWorkitems;
var workitemsPerPage = 25;
selectedWorkItems = new Map();
var res;
var pg2;

var html1
var id1;
var id2;
var id3;
var n = 0;

if(document.readyState === "interactive")
{
		getVersion();
}

function getVersion()
{
	console.log(document.readyState);
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/customObject", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.readyState);
			console.log(this.status);
			res = JSON.parse(this.responseText);
			id1 = res.id1;
			id2 = res.id2;
			id3 = res.id3;
			html1 = res.html1;
			// console.log(res);
			// console.log(res == null)
			if(res != null)
			{
				jQuery("body").one('DOMSubtreeModified', id3 , function() 
				{
					//console.log(document.readyState);
					loadPageData();
				});
			}
		}

		
	}
}	

function loadPageData()
{
	// console.log("In side loadPageData")
	// 	console.log("id1 = "+res.id1+" id2 : "+res.id2+" id3 = "+res.id3);
  //Already loaded!	
	// setTimeout(function(){
		// console.log(jQuery(id1))
		jQuery(id1).after(html1);

			jQuery(id2).before('<div class="modalbox">'+
				'<div class="dialog">'+
						'<div style="min-height: 200px;">'+
						'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left">'+
							'<h4>Bulk Approve/Reject Request</h4>'+
							'</div>'+
							'<div style="visibility:hidden" id="error-text"></div>'+
							'<div id="loader"></div>'+
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						
						'<div style="padding-top: 8px;">'+
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()" >Cancel</button>'+
							'<span class="btn-group-xs-only">'+
							'<button style="visibility:hidden;float: right;" id="reject" onclick="reject()" aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
									'</button></span>'+ 
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
								'</label>'+
						'</div>'+
						'<br/>'+
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+'<button class="btn btn-default" onclick="dismiss()">Cancel</button>'+
								'<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
									
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
				'</div><span id="pgSpan" style="visibility:hidden"></span>')

				jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
												'</div>');

		document.getElementById("Overly").addEventListener("click", function(){
			
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
			jQuery('#loader').after(
				'<table id="item_table" style="visibility:hidden;">'+
							'<thead >'+
								'<tr>'+
									'<th class="left-text" style="width:2%;">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id)"/><b>&nbsp; '+
									'</th>'+
									
									'<th class="left-text" style="width:6%;">ID</th>'+
									'<th class="left-text" style="width:5%;">Requestee</th>'+
									'<th class="left-text" style="width:14%;">Requester</th>'+
									'<th class="left-text" style="width:14%;">Requested For</th>'+
									'<th class="left-text" style="width:4%;">Application</th>'+
									'<th class="left-text" style="width:2%;">Requested On</th>'+
									'<th class="left-text" style="width:12%;">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			
			getData(workitemsPerPage,1);
					//console.log("pg2 = "+pg2);
			
			var tableData = document.getElementById('table1');
		});

		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			var cmntBox = document.getElementsByClassName('cmnt');
			var cAllbox = document.getElementById('All');
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");

			selectedWorkItems.clear();
		});
}


	