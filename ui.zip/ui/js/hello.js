var helloUrl = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=helloPlugin';
console.log(helloUrl);
$(document).ready(function(){  
    $("ul.navbar-left li:first")
		.after(
				'<li class="dropdown">' +
				'		<a href="'+helloUrl+'" tabindex="0" role="menuitem"> Hello World' +
				'		</a>' +
				'</li>'
		);
});

function sayHello()
{
	const Http = new XMLHttpRequest();
	const url='http://localhost:8080/identityiq/rest/user/all';
	Http.responseType = 'json';
	Http.open("GET", url);
	Http.send();
	Http.onreadystatechange=(e)=>{
	console.log(Http.responseText);
	}
}




