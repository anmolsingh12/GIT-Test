//var helloWorldUrl = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=custom';
var obj;
jQuery(document).ready(function(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			obj = JSON.parse(this.responseText);
			//console.log(obj[0]);
			var html = '<tbody style="background-color:#deffff">';
			for (var i=0; i<obj.length; i++) {
		        console.log(obj[i]);
						//$.each(obj, function() {
						//var key1 = Object.keys(this)[0];
						//var value1 = this[key1];
						//var key2 = Object.keys(this)[1];
						/*var value2 = this[key2];
						var key3 = Object.keys(this)[2];
						var value3 = this[key3];
						var key4 = Object.keys(this)[3];
						var value4 = this[key4];
						var key5 = Object.keys(this)[4];
						var value5 = this[key5];*/
				html += '<tr>';
				html += '<td><input class="check" type="checkbox" name="check'+i+'" value="'+obj[i].Name+'" onclick="selectOne(this)"/></td>';
				html +=	'<td>' + obj[i].Id + '</td>';
				html +=	'<td>' + obj[i].Name + '</td>';
				html += '<td>' + obj[i].Type + '</td>';
				html += '<td>' + obj[i].Requester + '</td>';
				html += '<td>' + obj[i].Owner + '</td>';
				html += '<td>' + obj[i].Created + '</td>';	
				html += "</tr>";
			}
			html += '</tbody>';
			jQuery(html).appendTo('#item_table');
		}
	}
});

 function selectAll(source) {
	var checkboxes = document.getElementsByClassName('check');
	for (var i=0; i<checkboxes.length; i++) {
		checkboxes[i].checked = source.checked;
        console.log(i + (checkboxes[i].checked?' checked ':' unchecked ') + checkboxes[i].value);
    }
}

function selectOne(el) {
	var cbox = $(el).attr('value');
	if ($('input.check').is(':checked')) {
		console.log(' checked ' + cbox);
	}
	else {
		console.log(' unchecked ' + cbox);
	}
}

jQuery(document).ready(function(){
	jQuery("#approve").click(function(){
		var favorite = [];
		$.each($("input[class='check']:checked"), function(){            
            favorite.push($(this).val());
			console.log(favorite);
        });
		//for (var i=0;i<favorite.length; i++)
		//{
			var myJson = JSON.stringify(favorite);
			var xhttp = new XMLHttpRequest();
			xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
			xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
			xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhttp.send({
					data:{
						ids: myJson
					}
			});
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					//console.log(this.responseText);
					obj = this.responseText;
					console.log(obj);
				}
			}
		//}
	});
});