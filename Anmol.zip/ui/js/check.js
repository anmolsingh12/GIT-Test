
jQuery(window).load(function(){
    setTimeout(function(){
        var url = SailPoint.CONTEXT_PATH + '/plugins/pluginPage.jsf?pn=customCheck';

    jQuery('.x-grid-cell-gridcolumn-1019').html('<div class="x-grid-cell-inner"><input class="check" onclick="displayId(`check`)" style="margin-top:10px; margin-left:15px; border-bottom:1rem solid black" type="checkbox"/></div>');
    
    jQuery('.x-grid-cell-gridcolumn-1019').removeClass('x-grid-cell x-grid-cell-gridcolumn-1019 x-grid-cell-first').addClass('x-grid-cell-gridcolumn-1019');
    
    jQuery('#gridcolumn-1019').html('<input class="checkAll" onclick="displayId(`checkAll`)" style="margin-top:8px; margin-left:2px;" type="checkbox" />&nbspSelect All');

    jQuery('#toolbar-1034-innerCt').append('<em id="button-1036-btnWrap"><button style="position: absolute; right: 0px; width: 250px; border: 1px solid black; padding: 6px;" id="button-1036-btnEl" onclick="approve()" type="button" class="" hidefocus="true" role="button" autocomplete="off" style=""><span id="button-1036-btnInnerEl" class="x-btn-inner" >Approve Workitems</span><span id="button-1036-btnIconEl" class="x-btn-icon "></span></button></em>')

    jQuery('#toolbar-1034-innerCt').append('<em id="button-1036-btnWrap"><button style="position: absolute; right: 300px; width: 150px; border: 1px solid black; padding: 6px;" id="button-1036-btnEl" onclick="location.href='+url+';" type="button" hidefocus="true" role="button" autocomplete="off"><span id="button-1036-btnInnerEl" class="x-btn-inner">Overlay</span><span id="button-1036-btnIconEl" class="x-btn-icon "></span></button></em>')

    createIndexId();
    },1500);
});


// function display()
// {
//  var e = document.getElementById("ogrooModel");

//         e[0].style.display = 'block';
// document.getElementById("close").addEventListener("click", function(){
//    var e =document.getElementsByClassName("modalbox");
//  e[0].style.display= 'none';
// });
// }

// function overlay() {

//     if(!jQuery('.ogroobox').is(':visible')){
//         jQuery(".ogroobox").slideDown(1000);

//     }else{
//         jQuery(".ogroobox").fadeOut(500);
//     }
// }
// jQuery(".overly").click(function(){
// overlay() ;
// })




function createIndexId()
{
    var i = 0, j = 1, k = 0;
    jQuery('input[type="checkbox"]').each(function(){
        //console.log(jQuery('input[type="checkbox"]')[i]);
        jQuery(this).attr('id', 'check'+i);
        i++;
    })

    jQuery('td.x-grid-cell.x-grid-cell-gridcolumn-1018').each(function(){
        //console.log(jQuery('td.x-grid-cell.x-grid-cell-gridcolumn-1018'));
        var val = jQuery('td.x-grid-cell.x-grid-cell-gridcolumn-1018')[k].innerText
        jQuery(jQuery('input[type="checkbox"]')[j]).val(val.toString().substring(0,3));
        j++;
        k++;
    })
}

var checkedBoxes = [];
workitemsToApprove = [];
function arrayToString(array)
{
    result = "";
    for(var i = 0; i < array.length; i++)
    {
       result += array[i]+",";
    }
    console.log(result);
    return result;
}

function approve()
{
    workitems = arrayToString(workitemsToApprove);
    console.log(workitems);

    // var xhttp = new XMLHttpRequest();
    // xhttp.open("GET", "/identityiq/plugin/rest/workitem/approve/"+workitems, true);
    // xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
    // xhttp.send();
    // xhttp.onreadystatechange = function() {
    //     if (this.readyState == 4 && this.status == 200) {
    //         console.log(this.responseText);
    //         obj = this.responseText;
    //         console.log(obj);
    //     }
    // }
}

function hasDuplicates(array) {
    var valuesSoFar = Object.create(null);
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if (value in valuesSoFar) {
            return true;
        }
        valuesSoFar[value] = true;
    }
    return false;
}

function displayId(id)
{
    
    if(id == 'check')
    {
        var cAllb = document.getElementsByClassName('checkAll');
        var cboxes = document.getElementsByClassName(id);
        var len = cboxes.length;

        if(cAllb[0].checked)
            cAllb[0].checked =  false;

        for (var i=0; i<len; i++) 
        {
            if(cboxes[i].checked)
            {
                checkOne(cboxes, i);
                console.log(i + ' checked '+ cboxes[i].value.toString());
                if(workitemsToApprove.includes(cboxes[i].value.toString()))
                     continue;
                
                else
                    workitemsToApprove.push(cboxes[i].value.toString());
            }
            else if(!cboxes[i].checked)
            {
                unCheckOne(cboxes, i);
                console.log(i + ' unchecked '+ cboxes[i].value.toString());   
                workitemsToApprove.splice(i);
            }
            console.log(workitemsToApprove);
        }

    }

    else
    {
        var cAllbox = document.getElementsByClassName(id);
            if(cAllbox[0].checked)
            {
                console.log("Inside If")
                var cboxes = document.getElementsByClassName('check');
                checkAll(cboxes);
                if(workitemsToApprove.length > 0)
                {
                    console.log("Array has values")
                    for(var j = 0; j < workitemsToApprove.length; j++ )
                    {
                        workitemsToApprove.splice(j);
                    }

                    for(var k = 0; k < cboxes.length; k++ )
                    {
                        console.log(cboxes[k].value.toString())
                        workitemsToApprove.push(cboxes[k].value.toString()); 
                    }

                }
                else
                {
                    console.log("Array is empty")
                    for(var k = 0; k < cboxes.length; k++ )
                    {
                        console.log(cboxes[k].value.toString())
                        workitemsToApprove.push(cboxes[k].value.toString()); 
                    }
                }
                console.log(' checked '+ cAllbox[0].value);
                console.log(workitemsToApprove);
                
            }

            else if(!cAllbox[0].checked)
            {
                var cboxes = document.getElementsByClassName('check');
                uncheckAll(cboxes);

                for(var j = 0; j < workitemsToApprove.length; j++ )
                {
                    workitemsToApprove.splice(j);
                }

                console.log(' unchecked '+ cAllbox[0].value);  
                console.log(workitemsToApprove); 
            }
        }
    }

function checkAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
        cboxes[i].checked = true;
    }
}

function uncheckAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
        cboxes[i].checked = false;
    }
}

function checkOne(cboxes, i)
{
    cboxes[i].checked = true;
}

function unCheckOne(cboxes, i)
{
    cboxes[i].checked = false;
}