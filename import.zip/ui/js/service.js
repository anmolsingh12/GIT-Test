function getData(pageSize,pageCount)
{
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.setRequestHeader('pageSize', pageSize);
	xhttp.setRequestHeader('pageCount', pageCount);
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			objString = this.responseText.toString();
			console.log(this.responseText);
			
			if(objString.charAt(0) == '<' )
			{
				//console.log("Some Error Occurred!!");
				
				jQuery('#error-text').css("visibility","visible");
				jQuery('#error-text').addClass("formError"); 
				jQuery('#error-text')[0].innerHTML = "Some Error Occured!! Contact System Admin";
			}
			
			else
			{
				obj = JSON.parse(this.responseText);
				if(obj.length <= 0 )
				{
						jQuery('#error-text').css("visibility","visible");
						jQuery('#error-text').removeClass('formError');
						jQuery('#error-text').addClass("formWarn"); 
						jQuery('#error-text')[0].innerHTML = "No Records to Display for Bulk Operation";
						jQuery('#loader').css("display", "none");

						jQuery('#item_table').css("visibility", "hidden");
						jQuery('#btn-grp').css("visibility", "hidden");
						jQuery('#approve').css("visibility", "hidden");
						jQuery('#reject').css("visibility", "hidden");
						jQuery('#com-cmnt').css("visibility", "hidden");
						jQuery('#bottom-display')[0].innerHTML = 'No Data to Display'
				}

				else if (obj === 'undefined')
				{	
					jQuery('#error-text').css("visibility","visible");
					jQuery('#error-text').removeClass('formError');
					jQuery('#error-text').addClass("formWarn");
					jQuery('#error-text')[0].innerHTML = "Data format not Supported!!"
					jQuery('#loader').css("display", "none")

					jQuery('#item_table').css("visibility", "hidden");
					jQuery('#btn-grp').css("visibility", "hidden");
					jQuery('#approve').css("visibility", "hidden");
					jQuery('#reject').css("visibility", "hidden");
					jQuery('#com-cmnt').css("visibility", "hidden");
				}

				else
				{
					totalWorkitems = obj[0].totalItems;
					console.log(totalWorkitems);
					jQuery('#error-text').css("visibility","hidden");
					jQuery('#error-text')[0].innerHTML = "";
					jQuery('#loader').css("display", "block")
					pg = obj[0].NoOfPages;
					document.getElementById("pgSpan").innerHTML = pg;
					var pg1=document.getElementById("pgSpan").innerHTML;
					loadData();
				}
			}
			
		}
		if (this.readyState == 4 && this.status != 200)
		{
			//console.log("Error Occured")
		}
		
	}
	////console.log(window.pg1);
}

function approve()
{
		var result={};
	console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i=0;i<selectedWorkItems.size;i++)
		{
			result[keys.next().value] = val.next().value;
		}
		console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				console.log(currentPage)
				/*console.log("Hello");
				jQuery(".post").remove();
				jQuery('#success-text').css('visibility', 'visible');
				jQuery('#success-text').addClass("formInfo");
				jQuery('#success-text')[0].innerHTML = "Your Request has been successfully submitted.";
				dismiss();
				selectedWorkItems.clear();
				getData(workitemsPerPage,currentPage);*/
				window.location.reload();
			}
		}
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
	jQuery('#loader').css("display", "none")
}

function reject()
{
	var result={};
	console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i=0;i<selectedWorkItems.size;i++)
		{
			result[keys.next().value] = val.next().value;
		}
		console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/reject", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				console.log(currentPage)
				/*console.log("Hello");
				jQuery(".post").remove();
				jQuery('#success-text').css('visibility', 'visible');
				jQuery('#success-text').addClass("formInfo");
				jQuery('#success-text')[0].innerHTML = "Your Request has been successfully submitted.";
				dismiss();
				selectedWorkItems.clear();
				getData(workitemsPerPage,currentPage);*/
				window.location.reload();
			}
		}
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
	jQuery('#loader').css("display", "none")
}

function getVersion()
{
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/customObject", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.send();
	xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log(this.responseText);
			}
		}
}