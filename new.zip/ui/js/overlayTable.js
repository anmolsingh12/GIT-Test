//Global Objects and variables declared here;

var obj; //Contains workitems served from server in a single table page load.
var resultObject; //Contains response from server after approval or rejection.
var pg;
var totalWorkitems; //Total number of workitems of a logged in user in sailpoint
var workitemsPerPage = 25; //Number of workitems to be shown in a single table page load.
selectedWorkItems = new Map(); //Contains a map with Workitem id as Key and Workitem comment as value.
//Contains selected workitems for bulk action by user.

var res; //Gets data from Custom Object created to load elements on page.
var pg2; //Total number of pages in pagination table.

var html1 //HTML code to be put for creation of button on Workitems.jsf page
var id1; //Gets the id of native element on workitems.jsf page to put Bulk Action Button after it using jQuery.
var id2; //Gets the id of native element on workitems.jsf page to put Bulk Action Overlay Table before it using jQuery.
var id3; //Gets the id of native element on workitems.jsf page to check if all elements on the page has been loaded.

var n = 0;
/**
 * When document is in loading state, call the getVersion() to get data from Sailpoint Custom Object
 */
if(document.readyState === "interactive")
{
		getVersion();
}

/**
 * REST function call to get data[id1, id2, id3 and html1] from custom Object
 */
function getVersion()
{
	console.log(document.readyState);
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/customObject", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.readyState);
			console.log(this.status);
			res = JSON.parse(this.responseText);
			id1 = res.id1;
			id2 = res.id2;
			id3 = res.id3;
			html1 = res.html1;
			// console.log(res);
			// console.log(res == null)
			if(res != null)
			{
				jQuery("body").one('DOMSubtreeModified', id3 , function() 
				{
					//console.log(document.readyState);
					loadPageData();
				});
			}
		}	
	}
}	


/**
 * Loads jQuery dynamic elements to load Button and Overlay on the page. 
 */
function loadPageData()
{
		jQuery(id1).after(html1);//Creation of Bulk Action Button

			//Creation of Bulk Action Table Overlay
			jQuery(id2).before('<div class="modalbox">'+
				'<div class="dialog">'+
						'<div style="min-height: 200px;">'+
						'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left">'+
							'<h4>Bulk Approve/Reject Request</h4>'+
							'</div>'+
							
							//Error or Warning text
							'<div style="visibility:hidden" id="error-text"></div>'+
							
							//CSS Loader
							'<div id="loader"></div>'+

							//Pagination Button Group
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						
						
						'<div style="padding-top: 8px;">'+
							//Cancel Button for table overlay
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()" >Cancel</button>'+
							'<span class="btn-group-xs-only">'+
							
							//Reject Button for table overlay
							'<button style="visibility:hidden;float: right;" id="reject" onclick="reject()" aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							
							//Approve Button for table overlay
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
									'</button></span>'+
									//Common Comments Check Box 
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
								'</label>'+
						'</div>'+
						'<br/>'+
						
						//Common Comment Overlay
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+'<button class="btn btn-default" onclick="dismissCommonComment()">Cancel</button>'+
								'<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
									
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
					
					//Hidden Span Used to store totalPages value for pagination table
				'</div><span id="pgSpan" style="visibility:hidden"></span>')
				
				//Success text
				jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
												'</div>');
		//jQuery for Opening Overlay onclick of Bulk Action(id="Overly") Button
		document.getElementById("Overly").addEventListener("click", function(){
			
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';

			//Creating table header and structure here.
			jQuery('#loader').after(
				'<table id="item_table" style="visibility:hidden;">'+
							'<thead >'+
								'<tr>'+
									'<th class="left-text" style="width:2%;">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id)"/><b>&nbsp; '+
									'</th>'+
									
									'<th class="left-text" style="width:6%;">ID</th>'+
									'<th class="left-text" style="width:5%;">Requestee</th>'+
									'<th class="left-text" style="width:14%;">Requester</th>'+
									'<th class="left-text" style="width:14%;">Requested For</th>'+
									'<th class="left-text" style="width:4%;">Application</th>'+
									'<th class="left-text" style="width:2%;">Requested On</th>'+
									'<th class="left-text" style="width:12%;">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			//REST call to get workitems for present showing page on Overlay Table.
			getData(workitemsPerPage,1);
		});

		//jQuery for Closing Overlay onclick of Cancel(id="close") Button

		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			var cmntBox = document.getElementsByClassName('cmnt');
			var cAllbox = document.getElementById('All');
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");

			selectedWorkItems.clear();
			workitemsPerPage = 25;
		});
}


	