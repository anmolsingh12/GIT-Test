/** 
 * getData() function gets data from server about list of workitems.
 * returns : a JSON Object with properties as
 * {
		Application: ""
		Created: ""
		Description: ""
		Id: ""
		Name: ""
		No: 
		NoOfPages: 
		Operation: ""
		Owner: ""
		Requestee: ""
		Requester: ""
		Type: ""
		totalItems: 
	}
*/

function getData(pageSize,pageCount)
{
	console.log(Ext.util.Cookies.get('CSRF-TOKEN'));
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.setRequestHeader('pageSize', pageSize);
	xhttp.setRequestHeader('pageCount', pageCount);
	xhttp.send();
	xhttp.onreadystatechange = function() {
		console.log("Inside getdata()");
		if (this.readyState == 4 && this.status == 200) {
			objString = this.responseText.toString();
			console.log(this.responseText);
			
			if(objString.charAt(0) == '<' )
			{
				//console.log("Some Error Occurred!!");
				
				jQuery('#error-text').css("visibility","visible");
				jQuery('#error-text').addClass("formError"); 
				jQuery('#error-text')[0].innerHTML = "Some Error Occured!! Contact System Admin";
			}
			
			else
			{
				obj = JSON.parse(this.responseText);
				if(obj.length <= 0 )
				{
						jQuery('#error-text').css("visibility","visible");
						jQuery('#error-text').removeClass('formError');
						jQuery('#error-text').addClass("formWarn"); 
						jQuery('#error-text')[0].innerHTML = "No Records to Display for Bulk Operation";
						jQuery('#loader').css("display", "none");

						jQuery('#item_table').css("visibility", "hidden");
						jQuery('#btn-grp').css("visibility", "hidden");
						jQuery('#approve').css("visibility", "hidden");
						jQuery('#reject').css("visibility", "hidden");
						jQuery('#com-cmnt').css("visibility", "hidden");
						jQuery('#bottom-display')[0].innerHTML = 'No Data to Display'
				}

				else if (obj === 'undefined')
				{	
					jQuery('#error-text').css("visibility","visible");
					jQuery('#error-text').removeClass('formError');
					jQuery('#error-text').addClass("formWarn");
					jQuery('#error-text')[0].innerHTML = "Data format not Supported!!"
					jQuery('#loader').css("display", "none")

					jQuery('#item_table').css("visibility", "hidden");
					jQuery('#btn-grp').css("visibility", "hidden");
					jQuery('#approve').css("visibility", "hidden");
					jQuery('#reject').css("visibility", "hidden");
					jQuery('#com-cmnt').css("visibility", "hidden");
				}

				else
				{
					console.log("Data received");
					totalWorkitems = obj[0].totalItems;
					//console.log(totalWorkitems);
					jQuery('#error-text').css("visibility","hidden");
					jQuery('#error-text')[0].innerHTML = "";
					jQuery('#loader').css("display", "block")
					document.getElementById("pgSpan").innerHTML = obj[0].NoOfPages;
					var pg1=document.getElementById("pgSpan").innerHTML;
					console.log("No. Of Pages = "+pg1);
					pg2 = pg1;
					console.log("###"+pg2);
					var btnGrp = document.getElementById('btn-grp');
					html = '<td colspan="8">'
					html += '<button id="backward" onclick="goBackward()" class="btn btn-default"><i class="fa fa-step-backward"></i></button>&nbsp;&nbsp;';
					html += '<button id="left" onclick="goLeft()" class="btn btn-default"><i class="fa fa-arrow-left"></i></button>&nbsp;&nbsp;';
					html += '<span>Page &nbsp;&nbsp;<input id="pageCount" onkeyup="changePageOnText(event)" value="1" type="text" style="height: 30px; width: 30px;padding:5px;"/></span> of <span id="numPages">'+obj[0].NoOfPages+'&nbsp;&nbsp;</span>';
					html += '<button id="right" onclick="goRight()" class="btn btn-default"><i class="fa fa-arrow-right"></i></button>&nbsp;&nbsp;';
					html += '<button id="forward" onclick="goForward()" class="btn btn-default"><i class="fa fa-step-forward"></i></button>&nbsp;&nbsp;';
					html += '<button id="refresh" onclick="doRefresh()" class="btn btn-default"><i class="fa fa-refresh"></i></button>&nbsp;&nbsp;';
					html += 'Show &nbsp;&nbsp;<select onchange="getWorkitemValues(this)" class="numOfwi" id="selectItems"><option>5</option><option>10</option><option>20</option><option>25</option><option>50</option><option>100</option></select>&nbsp;&nbsp; items';
					html += '<span id="bottom-display" class="float-xs-right" style="float:right;padding-top:10px;">No Data to Display</span>';
					html += '</td>'
					btnGrp.innerHTML = html
					while(true)
					{
						if(pg1.length > 0)
						{
							loadData();
							document.getElementById("pageCount").value = pageCount;
							jQuery('#selectItems')[0].value = workitemsPerPage;
							jQuery("#numPages").innerHTML = pg2;
							break;
						}
					}
				}
			}
			
		}		
	}
	////console.log(window.pg1);
}

/**
 * Sends a list of workitems[key value pair of with key = name of workitem and value = comments]
 * for bulk approval.
 */
function approve()
{
	//jQuery('#loader').css("display", "block")
		var result={};
	//console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i=0;i<selectedWorkItems.size;i++)
		{
			result[keys.next().value] = val.next().value;
		}
		//console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				console.log(currentPage)
				window.location.reload();
			}
		}
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
}

/**
 * Sends a list of workitems[key value pair of with key = name of workitem and value = comments]
 * for bulk rejection.
 */
function reject()
{
	var result={};
	//console.log(selectedWorkItems);
	if(selectedWorkItems.size > 0)
	{
		var keys = selectedWorkItems.keys();
		var val = selectedWorkItems.values();
		for (var i=0;i<selectedWorkItems.size;i++)
		{
			result[keys.next().value] = val.next().value;
		}
		//console.log(result);
		var xhttp = new XMLHttpRequest();
		xhttp.open("POST", "/identityiq/plugin/rest/test/reject", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send(JSON.stringify(result));
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				resultObject = this.responseText;
				var currentPage = document.getElementById('pageCount').value;
				//console.log(currentPage)
				/*console.log("Hello");
				jQuery(".post").remove();
				jQuery('#success-text').css('visibility', 'visible');
				jQuery('#success-text').addClass("formInfo");
				jQuery('#success-text')[0].innerHTML = "Your Request has been successfully submitted.";
				dismiss();
				selectedWorkItems.clear();
				getData(workitemsPerPage,currentPage);*/
				window.location.reload();
			}
		}
	}
	else
	{
		jQuery('#error-text').css('visibility', 'visible');
		jQuery('#error-text').addClass("formWarn"); 
		jQuery('#error-text')[0].innerHTML = "Please select at least One check box";
	}
	jQuery('#loader').css("display", "none")
}