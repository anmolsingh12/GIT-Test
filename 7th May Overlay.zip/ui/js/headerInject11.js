
var obj;
jQuery(document).ready(function(){
	setTimeout(function(){
		jQuery("#button-1035").after(
			'<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 400px; top: 3px; margin: 0px;">'+
			 	'<em id="button2">'+
				  	'<button id="Overly" type="button" class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;">'+
					  	'<span id="button4" class="x-btn-inner" style="">Bulk Approval</span>'+
						  '<span id="button5" class="x-btn-icon "></span>'+
						  		'</button></em></div>');
		
		jQuery('div.classic-body-container').append(
			'<div id="ogrooModel" class="modalbox ogroobox">'+
				'<div class="dialog">'+
					 '<div style="min-height: 200px;">'+
					 	'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left">'+
						 	'<h3>Bulk Approve Request</h3>'+
						 '</div>'+
						 '<div style="visibility:hidden"id="error-text"></div>'+
						 '<div id="loader"></div>'+
						 '<table id="item_table" style="visibility:hidden">'+
						 	'<thead>'+
							 	'<tr>'+
								 	'<th style="text-align: left">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id)"/><b>&nbsp; '+
									'</th>'+
									
									'<th style="text-align: left">ID</th>'+
									'<th style="text-align: left">Requestee</th>'+
									'<th style="text-align: left">Requester</th>'+
									'<th style="text-align: left">Requested For</th>'+
									'<th style="text-align: left">Application</th>'+
									'<th style="text-align: left">Requested On</th>'+
									'<th style="text-align: left">Comments</th>'+
								'</tr>'+
							'</thead>'+
						'</table>'+
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						'<div style="padding: 8px;">'+
							'<button  style="float: left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>'+
							'<span class="btn-group-xs-only">'+
							'<button style="visibility:hidden;float: right;" id="reject"  aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden; float: right;">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>Approve All'+
									'</button></span>'+  
								
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value="">&nbsp;Common Comments'+
								'</label>'+
						'</div>'+
						'<br/>'+
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+
									'<button class="btn btn-default" onclick="approve()">Approve All</button>&nbsp;&nbsp;'+
									'<button class="btn btn-default" onclick="dismiss()">Cancel</button>'+
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
				'</div>');

		document.getElementById("Overly").addEventListener("click", function(){
			getData();
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
		});

		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			var cmntBox = document.getElementsByClassName('cmnt');
			var cAllbox = document.getElementById('All');
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");

			if(cAllbox.checked)
				cAllbox.checked = false;
		});
		
	}, 1000);
	});

class WorkItem {
    constructor(id, comment) {
        this.id = id;
        this.comment = comment;
    }
}

selectedWorkItems = new Map();

function getData()
{
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			objString = this.responseText.toString();
			
			if(objString.charAt(0) == '<' )
			{
				console.log("Some Error Occurred!!");
				
				jQuery('#error-text').css("visibility","visible");
				jQuery('#error-text').addClass("formError"); 
				jQuery('#error-text')[0].innerHTML = "Some Error Occured!! Contact System Admin";
			}
			
			else
			{
				obj = JSON.parse(this.responseText);
				if(obj.length <= 0)
				{
					jQuery('#error-text').css("visibility","visible");
					jQuery('#error-text').addClass("formError"); 
					jQuery('#error-text')[0].innerHTML = "No Records to Display"
				}

				else if (obj === 'undefined')
				{	
					jQuery('#error-text').css("visibility","visible");
					jQuery('#error-text').addClass("formError"); 
					jQuery('#error-text')[0].innerHTML = "Data format not Supported!!"
				}

				else
				{
					jQuery('#loader').css("display", "block")
					loadData();
				}
			}
		}
		if (this.readyState == 4 && this.status != 200)
		{
			console.log("Error Occured")
		}
	}
}

function loadData()
{
	myVar = setTimeout(showTable, 1500);
}

function showTable() {
	document.getElementById("loader").style.display = "none";
	jQuery('#item_table').css("visibility","visible");
	jQuery('#reject').css("visibility","visible");
	jQuery('#approve').css("visibility","visible"); 
	jQuery('#com-cmnt').css("visibility", "visible")
	jQuery('#btn-grp').css("visibility", "visible")

	var html = '<tbody style="background-color:##E5E8E8">';
	for (var i=0; i<obj.length; i++) {
		console.log(obj[i]);
		html += '<tr class="post" title="'+obj[i].Description+'">';
		html += '<td><input class="check" type="checkbox" id="check'+obj[i].Name+'" value="'+obj[i].Name+'" onclick="checkState(this.id)"/></td>';
		html +=	'<td>'+ obj[i].Name +'</td>';
		html +=	'<td>' + obj[i].Requestee + '</td>';
		html += '<td>' + obj[i].Requester + '</td>';
		html +=	'<td>' + obj[i].Operation + '</td>';
		html += '<td>' + obj[i].Application + '</td>';
		html += '<td>' + obj[i].Created + '</td>';
		html += '<td><input disabled="disabled" type="text" class="cmnt" oninput="changeCmntValue(this.id)" id="cmnt'+obj[i].Name+'"/></td>';						
		html += "</tr>";
	}
	html += '</tbody>';
	jQuery(html).appendTo('#item_table');

	var btnGrp = document.getElementById('btn-grp');
	html = '<td colspan="8">'
	html += '<button class="btn btn-default"><i class="fa fa-step-backward"></i></button>&nbsp;&nbsp;';
	html += '<button class="btn btn-default"><i class="fa fa-arrow-left"></i></button>&nbsp;&nbsp;';
	html += '<span>Page &nbsp;&nbsp;<input type="text" style="height: 30px; width: 30px;"/></span> of x&nbsp;&nbsp;';
	html += '<button class="btn btn-default"><i class="fa fa-arrow-right"></i></button>&nbsp;&nbsp;';
	html += '<button class="btn btn-default"><i class="fa fa-step-forward"></i></button>&nbsp;&nbsp;';
	html += '<button class="btn btn-default"><i class="fa fa-refresh"></i></button>&nbsp;&nbsp;';
	html += '</td>'
	btnGrp.innerHTML = html;
}

function dismiss()
{
	var el = document.getElementsByClassName("cmnt-modal");
	el[0].style.display = 'none';
	jQuery('#com-cmnt-checkbox')[0].checked = false;
	var comment = document.getElementById('comment');
	comment.value = "";
	jQuery('.cmnt').each(function() {
			jQuery(this).attr("disabled", "disabled")
			jQuery(this).attr("value", "")		
	})

}

function addCommonComment(objId)
{
	var comment = document.getElementById(objId);
	var keys = selectedWorkItems.keys();
	keys;

	selectedWorkItems.forEach(function(){
		selectedWorkItems.set(keys.next().value, comment.value);
	})
}


function openCommonCommentBox()
{
	var el = document.getElementsByClassName("cmnt-modal");
	el[0].style.display = 'block';
	
	var chckBox = document.getElementById('com-cmnt-checkbox');

	if(chckBox.checked)
	{
		jQuery('#cmnt-box').css("visibility", "visible");
		
		jQuery('.cmnt').each(function() {
			jQuery(this).attr("disabled", "disabled");
			document.getElementById(this.id).value = "";
		})
	}

	else
	{
		jQuery('#cmnt-box').css("visibility", "hidden");
		
		jQuery('.cmnt').each(function() {
			jQuery(this).removeAttr('disabled');		
		})

		var keys = selectedWorkItems.keys();
		selectedWorkItems.forEach(function(){
			selectedWorkItems.set(keys.next().value, "");
		})
		var cmntBox = document.getElementById('comment');
		cmntBox.value = "";
	}
}

function changeCmntValue(id)
{
	var cmntBox = document.getElementById(id);
	var cmnt = cmntBox.value;
	var idVal = id.substring(4);
	selectedWorkItems.set(idVal,cmnt);
}

function checkState(id)
{
	if(id == "All")
	{
		var cmntBox = document.getElementsByClassName('cmnt');
        var cAllbox = document.getElementById(id);

		if(cAllbox.checked)
		{
			var cboxes = document.getElementsByClassName('check');
			checkAll(cboxes);
			
			if(selectedWorkItems.size > 0)
			{
				console.log("Array has values")
				
				selectedWorkItems.clear();
				

				for(var k = 0; k < cboxes.length; k++ )
				{
					console.log(cboxes[k].value.toString())
					selectedWorkItems.set(cboxes[k].value.toString(), cmntBox[k].value ); 
				}

			}
			else
			{
				for(var k = 0; k < cboxes.length; k++ )
				{
					selectedWorkItems.set(cboxes[k].value.toString(), cmntBox[k].value ); 
				}
			}			
		}

		if(!cAllbox.checked)
		{
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			selectedWorkItems.clear();
			console.log(' unchecked '+ cAllbox.value);  
		}
	}

	else
	{
		var cAllb = document.getElementById('All'); 
		var checkbox = document.getElementById(id);

		 if(cAllb.checked)
            cAllb.checked =  false;

		if(checkbox.checked)
		{
			jQuery('#cmnt'+checkbox.value).removeAttr("disabled");
			console.log({id : checkbox.value.toString(), comment : jQuery('#cmnt'+checkbox.value)[0].value });
			selectedWorkItems.set(checkbox.value.toString(), jQuery('#cmnt'+checkbox.value)[0].value );
		}

		else
		{
			jQuery('#cmnt'+checkbox.value).attr("disabled", "disabled");
			console.log({id : checkbox.value.toString(), comment : jQuery('#cmnt'+checkbox.value)[0].value });
			selectedWorkItems.delete(checkbox.value.toString());
		}
	}
}

function checkAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		console.log(cboxes[i].value);
		jQuery('#cmnt'+cboxes[i].value).removeAttr('disabled');
        cboxes[i].checked = true;
    }
}

function uncheckAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		jQuery('#cmnt'+cboxes[i].value).attr("disabled", "disabled");
        cboxes[i].checked = false;
    }
}

function approve()
{
	console.log(selectedWorkItems);
}