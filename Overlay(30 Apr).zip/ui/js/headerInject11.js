jQuery(document).ready(function(){
	setTimeout(function(){
		jQuery("#button-1036").after('<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 400px; top: 3px; margin: 0px;"> 	 	<em id="button2"> 	 		<button id="Overly" type="button" class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;"> 	 			<span id="button4" class="x-btn-inner" style="">Bulk Approval</span> 	 			<span id="button5" class="x-btn-icon "></span> 	 		</button> 	 	</em> 	 </div>');
		jQuery('div.classic-body-container').append('<div id="ogrooModel" class="modalbox ogroobox"> 	 	<div class="dialog"> 	 			 		<div  style="min-height: 200px;"> <div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left"><h3>Bulk Approve Request</h3></div> 			<table id="item_table"> 	 				<thead> 	 					<tr> 	 						<th style="text-align: left"><input type="checkbox" class="all" onclick="displayId(`all`)"/><b>&nbsp; </th> 	 						<th style="text-align: left">ID</th> 	 						<th style="text-align: left">Requestee</th> 	 						<th style="text-align: left">Requester</th> 	 						<th style="text-align: left">Requested For</th> 	 						<th style="text-align: left">Application</th> 	 						<th style="text-align: left">Requested On</th><th style="text-align: left">Comments</th></tr> 	 				</thead> 	 			</table> 	 			<div style="padding: 8px;"><button  style="float: left;" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-s-sm ng-binding ng-scope btn-white "  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>	 				<span class="btn-group-xs-only"><button style="float: right;" id="reject"  aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" > <i class="fa fa-thumbs-down text-danger"  role="presentation"></i>Deny All</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px; "><button id="approve"    aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="float: right;"><i class="fa fa-thumbs-up text-success"  role="presentation"></i>Approve All</button></span> </div>	 			 		</div> 	 	</div> 	 </div>');
		document.getElementById("Overly").addEventListener("click", function(){
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
		});
		document.getElementById("close").addEventListener("click", function(){
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
		});
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				obj = JSON.parse(this.responseText);
				//console.log(obj[0]);
				var html = '<tbody style="background-color:##E5E8E8">';
				for (var i=0; i<obj.length; i++) {
					console.log(obj[i]);
					html += '<tr class="post">';
					html += '<td><input class="check" type="checkbox" name="check'+i+'" value="'+obj[i].Name+'" onclick="displayId(`check`)"/></td>';
					html +=	'<td>' + obj[i].Name + '</td>';
					html +=	'<td>' + obj[i].Requestee + '</td>';
					html += '<td>' + obj[i].Requester + '</td>';
					html +=	'<td>' + obj[i].Operation + '</td>';
					html += '<td>' + obj[i].Application + '</td>';
					html += '<td>' + obj[i].Created + '</td>';
					html += '<td><input type="text" style="visibility: hidden;" class="cmnt" id="cmnt'+i+'"/></td>';						
					html += "</tr>";
				}
				html += '</tbody>';
				jQuery(html).appendTo('#item_table');
			}
		}
	//}); 

	
	//jQuery(document).ready(function(){
		jQuery("#approve").click(function(){
			/*var favorite = [];
			jQuery.each(jQuery("input[class='check']:checked"), function(){            
				favorite.push(jQuery(this).val());
				console.log(favorite);
			});
			for (var i=0;i<favorite.length; i++)
			{
				var xhttp = new XMLHttpRequest();
				xhttp.open("GET", "/identityiq/plugin/rest/test/approval/"+favorite[i], true);
				xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
				xhttp.setRequestHeader('Content-Type', 'application/json');
				xhttp.send();
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						console.log(this.responseText);
						obj = this.responseText;
						console.log(obj);
					}
				}
			}*/
			var result={};
			jQuery.each(jQuery("input[class='check']:checked"), function(){ 
			result[jQuery(this).val()]=jQuery(this).val();
				//favorite.push(jQuery(this).val());
				//console.log(index+result[index]);
			});
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
				xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
				xhttp.setRequestHeader('Content-Type', 'application/json');
				//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
				xhttp.send(JSON.stringify(result));
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						//console.log(this.responseText);
						obj = this.responseText;
						//console.log(obj);
					}
				}
		});
	}, 1000);
	});
	
	function fff(){
		var result={};
			jQuery.each(jQuery("input[class='check']:checked"), function(index){ 
			result[index]=jQuery(this).val();
				//favorite.push(jQuery(this).val());
				//console.log(index+result[index]);
			});
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
				xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
				xhttp.setRequestHeader('Content-Type', 'application/json');
				//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
				xhttp.send(JSON.stringify(result));
				xhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) {
						//console.log(this.responseText);
						obj = this.responseText;
						//console.log(obj);
					}
				}
			
		}

var res;
class WorkItem {
    constructor(id, comment) {
        this.id = id;
        this.comment = comment;
    }
}

selectedWorkItems = [];

function printValues()
{
	var cmntBox = document.getElementsByClassName('cmnt');
	for(var i = 0; i < cmntBox.length; i++)
		console.log(cmntBox[i].value);
}

function displayId(className)
{
    
    if(className == 'check')
    {
		var cmntBox = document.getElementsByClassName('cmnt');
        var cAllb = document.getElementsByClassName('all');
        var cboxes = document.getElementsByClassName(className);
        var len = cboxes.length;

        if(cAllb[0].checked)
            cAllb[0].checked =  false;

        for (var i=0; i<len; i++) 
        {
            if(cboxes[i].checked)
            {
                checkOne(cboxes, i);
                console.log(i + ' checked '+ cboxes[i].value.toString());
                res = selectedWorkItems.push({id : cboxes[i].value.toString(), comment : cmntBox[i].value });
    			console.log(res);
				
			}
            else if(!cboxes[i].checked)
            {
				unCheckOne(cboxes, i);
                console.log(i + ' unchecked '+ cboxes[i].value.toString());   
                res = selectedWorkItems.splice({id : cboxes[i].value.toString(), comment : cmntBox[i].value });
    			console.log(res);
			}
        }

    }

    else
    {
		var cmntBox = document.getElementsByClassName('cmnt');
        var cAllbox = document.getElementsByClassName(className);
            if(cAllbox[0].checked)
            {
                console.log("Inside If")
                var cboxes = document.getElementsByClassName('check');
                checkAll(cboxes);
                if(selectedWorkItems.length > 0)
                {
                    console.log("Array has values")
                    for(var j = 0; j < selectedWorkItems.length; j++ )
                    {
					   selectedWorkItems.splice({id : cboxes[j].value.toString(), comment : cmntBox[j].value });
                    }

                    for(var k = 0; k < cboxes.length; k++ )
                    {
                        console.log(cboxes[k].value.toString())
                        selectedWorkItems.push({id : cboxes[k].value.toString(), comment : cmntBox[k].value }); 
                    }

                }
                else
                {
                    console.log("Array is empty")
                    for(var k = 0; k < cboxes.length; k++ )
                    {
						jQuery('#cmnt'+k).attr("style", "visibility: visible")
                        console.log(cboxes[k].value.toString())
                        selectedWorkItems.push({id : cboxes[k].value.toString(), comment : cmntBox[k].value }); 
                    }
                }
                console.log(' checked '+ cAllbox[0].value);
                
                
            }

            else if(!cAllbox[0].checked)
            {
                var cboxes = document.getElementsByClassName('check');
                uncheckAll(cboxes);

                for(var j = 0; j < selectedWorkItems.length; j++ )
                {
					selectedWorkItems.splice({id : cboxes[j].value.toString(), comment : cmntBox[j].value });
                }

                console.log(' unchecked '+ cAllbox[0].value);  
            }
        }
    }

function checkAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		jQuery('#cmnt'+i).attr("style", "visibility: visible")
        cboxes[i].checked = true;
    }
	console.log(selectedWorkItems);
}

function uncheckAll(cboxes)
{
    for(var i = 0; i < cboxes.length; i++)
    {
		jQuery('#cmnt'+i).attr("style", "visibility: hidden")
        cboxes[i].checked = false;
    }
	console.log(selectedWorkItems);
}

function checkOne(cboxes, i)
{
	jQuery('#cmnt'+i).attr("style", "visibility: visible")
    cboxes[i].checked = true;
	console.log(selectedWorkItems);
}

function unCheckOne(cboxes, i)
{
	jQuery('#cmnt'+i).attr("style", "visibility: hidden")
    cboxes[i].checked = false;
	console.log(selectedWorkItems);
}