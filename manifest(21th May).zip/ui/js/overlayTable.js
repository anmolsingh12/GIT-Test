var obj;
var resultObject;
var pg;
var totalWorkitems;
const workitemsPerPage = 3;
selectedWorkItems = new Map();

jQuery(document).ready(function(){
	setTimeout(function(){
		jQuery('table#manageSearchField.x-field.x-form-item.x-box-item.x-toolbar-item.x-field-default-toolbar.x-hbox-form-item').after(
			'<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon 		x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 400px; top: 3px; margin: 0px;">'+
				'<em id="button2">'+
					'<button id="Overly" type="button" class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;">'+
						'<span id="button4" class="x-btn-inner" style="">Bulk Action</span>'+
						'<span id="button5" class="x-btn-icon "></span>'+
					'</button>'+
				'</em>'+
			'</div>');

		jQuery('div.classic-body-container').append(
			'<div class="modalbox">'+
				'<div class="dialog">'+
					 '<div style="min-height: 200px;">'+
					 	'<div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding-top: 0px; padding-bottom: 4px; align:left">'+
						 	'<h4>Bulk Approve/Reject Request</h4>'+
						 '</div>'+
						 '<div style="visibility:hidden" id="error-text"></div>'+
						 '<div id="loader"></div>'+
						'<div id="btn-grp" style="border:1px solid #D5D8DC; padding: 5px;visibility:hidden"></div>'+
						
						'<div style="padding-top: 8px;">'+
							'<button  style="float:left" id="close" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-sm btn-white ng-binding"  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>'+
							'<span class="btn-group-xs-only">'+
							'<button style="visibility:hidden;float: right;" id="reject"  aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false">'+
								'<i class="fa fa-thumbs-down text-danger"  role="presentation"></i>&nbsp;Deny All'+
							'</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px;">'+
							'<button id="approve" onclick="approve()" aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="visibility:hidden;float:right;margin-right:16px">'+
								'<i class="fa fa-thumbs-up text-success" role="presentation"></i>&nbsp;Approve All'+
									'</button></span>'+ 
								'<label class="checkbox-inline" id="com-cmnt" style="visibility:hidden">&nbsp;'+
									'<input type="checkbox" id="com-cmnt-checkbox" onclick="openCommonCommentBox()" value=""><b>Common Comments</b>'+
								'</label>'+
						'</div>'+
						'<br/>'+
						'<div class="cmnt-modal form-group" id="cmnt-box">'+
							'<div class="dialog-box">'+
								'<label for="comment">Comment:</label>'+
								'<input type="text" class="form-control" id="comment" oninput="addCommonComment(this.id)" /><br/>'+
								'<div>'+'<button class="btn btn-default" onclick="dismiss()">Cancel</button>'+
								'<button class="btn btn-default" onclick="approve()" style="float: right;">Approve All</button>'+
									
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>'+
				'</div><span id="pgSpan" style="visibility:hidden"></span>');

				jQuery('div.panel-heading.tooltip-wrapper.container-fluid').after('<div style="visibility:hidden" id="success-text">'+
                                                '</div>');

		document.getElementById("Overly").addEventListener("click", function(){
			
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
			jQuery('#loader').after(
				'<table id="item_table" style="visibility:hidden;">'+
						 	'<thead >'+
							 	'<tr>'+
								 	'<th class="left-text" style="width:5%;">'+
										'<input type="checkbox" id ="All" class="all" onclick="checkState(this.id)"/><b>&nbsp; '+
									'</th>'+
									
									'<th class="left-text" style="width:15%;">ID</th>'+
									'<th class="left-text" style="width:10%;">Requestee</th>'+
									'<th class="left-text" style="width:20%;">Requester</th>'+
									'<th class="left-text" style="width:20%;">Requested For</th>'+
									'<th class="left-text"style="width:10%;">Application</th>'+
									'<th class="left-text" style="width:10%;">Requested On</th>'+
									'<th class="left-text" style="width:10%;">Comments</th>'+
								'</tr>'+
							'</thead></table>');
			
			getData(workitemsPerPage,1);
			setTimeout(function(){
			var pg2=document.getElementById("pgSpan").innerHTML;
				//console.log(pg2);
	var btnGrp = document.getElementById('btn-grp');
	html = '<td colspan="8">'
	html += '<button id="backward" class="btn btn-default"><i class="fa fa-step-backward"></i></button>&nbsp;&nbsp;';
						html += '<button id="left" class="btn btn-default"><i class="fa fa-arrow-left"></i></button>&nbsp;&nbsp;';
						html += '<span>Page &nbsp;&nbsp;<input id="pageCount" value="1" type="text" style="height: 20px; width: 20px;"/></span> of '+pg2+'&nbsp;&nbsp;';
						html += '<button id="right" class="btn btn-default"><i class="fa fa-arrow-right"></i></button>&nbsp;&nbsp;';
						html += '<button id="forward" class="btn btn-default"><i class="fa fa-step-forward"></i></button>&nbsp;&nbsp;';
						html += '<button id="refresh" class="btn btn-default"><i class="fa fa-refresh"></i></button>&nbsp;&nbsp;';
						html += '<span id="bottom-display" class="float-xs-right" style="float:right;padding-top:10px;">No Data to Display</span>';
	html += '</td>'
	btnGrp.innerHTML = html;

			
			var tableData = document.getElementById('table1');

			document.getElementById("pageCount").addEventListener("keyup", function(event) 
			{				
				if (event.keyCode === 13) 
				{
					event.preventDefault();
					var pageCount1 = jQuery("#pageCount").val();
					console.log(pageCount1);
					var regex = '/^[0-9]*$/';
					valueValid = false;

					for(var i = 0; i < pageCount1.toString().length; i++)
					{
						if(pageCount1.toString().charCodeAt(i) <= 57 && pageCount1.toString().charCodeAt(i) >= 49)
						{
							valueValid = true;
						}
						else
						{
							valueValid = false;
							break;
						}
					}

					if(valueValid == true && pageCount1 <= pg2)
					{
						jQuery(".post").remove();
						getData(workitemsPerPage,pageCount1);
					}
				}
			});
						jQuery("#right").click(function(){
							var pageCount1=jQuery("#pageCount").val();
							if(pageCount1<pg2)
							{
								pageCount1++; 
							}
							console.log(pageCount1);
							document.getElementById("pageCount").value=pageCount1;
							console.log(jQuery("#pageCount").val());
							//tableData.innerHTML = '';
							jQuery("#table1").remove();
							getData(workitemsPerPage,pageCount1);
						});

						jQuery("#left").click(function(){
							var pageCount1=jQuery("#pageCount").val();
							if(pageCount1>1)
							{
								pageCount1--;
							}
							document.getElementById("pageCount").value=pageCount1;
							console.log(pageCount1);
							jQuery("#table1").remove();
							getData(workitemsPerPage,pageCount1);
						});
						jQuery("#backward").click(function(){
							document.getElementById("pageCount").value=1;
							//console.log(pageCount1);
							jQuery("#table1").remove();
							getData(workitemsPerPage,1);
						});
						jQuery("#forward").click(function(){
						document.getElementById("pageCount").value=pg2;
							console.log(pg2);
							jQuery("#table1").remove();
							getData(workitemsPerPage,pg2);
						});
						jQuery("#refresh").click(function(){
							var pageCount1=jQuery("#pageCount").val();
							console.log(pageCount1);
							jQuery("#table1").remove();
							getData(workitemsPerPage,pageCount1);
						});
			},500);
			
		});

		document.getElementById("close").addEventListener("click", function(){
			document.getElementById("item_table").style.visibility = "hidden";
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
			var cboxes = document.getElementsByClassName('check');
			uncheckAll(cboxes);
			var cmntBox = document.getElementsByClassName('cmnt');
			var cAllbox = document.getElementById('All');
			for(var i = 0; i < cmntBox.length; i++)
			{
				cmntBox[i].value = "";
			}

			jQuery('#item_table').empty();
			
			jQuery('#cmnt-box').css("visibility", "hidden");
			jQuery('#btn-grp').css("visibility", "hidden");
			jQuery('#approve').css("visibility", "hidden");
			jQuery('#reject').css("visibility", "hidden");
			jQuery('#com-cmnt').css("visibility", "hidden");

			selectedWorkItems.clear();
		});
		
	}, 500);
	});