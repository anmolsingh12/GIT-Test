jQuery(document).ready(function(){
    setTimeout(function(){
    jQuery('.x-grid-cell-gridcolumn-1019').delay( 1000 ).html('<div class="x-grid-cell-inner"><input onclick="displayId(`check`)" style="margin-top:10px; margin-left:15px" type="checkbox" name="check" /></div>');
    jQuery('.x-grid-cell-gridcolumn-1019').removeClass('x-grid-cell x-grid-cell-gridcolumn-1019 x-grid-cell-first');
    jQuery('#gridcolumn-1019').delay( 1000 ).html('<input onclick="displayId(`check`)" style="margin-top:8px; margin-left:2px;" type="checkbox" name="check" />&nbspSelect All');
    },1000);
});