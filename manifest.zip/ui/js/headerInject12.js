jQuery(document).ready(function(){
	setTimeout(function() {
		jQuery("span[title='Latest Approvals']").after('<div id="button1" class="x-btn x-box-item x-toolbar-item x-btn-default-toolbar-medium x-noicon x-btn-noicon x-btn-default-toolbar-medium-noicon" style="border-width: 1px; left: 300px; top: 6px; margin: 0px;"> 	 	<em id="button2"> 	 		<button id="Overly" type="button" class="x-btn-center overly" hidefocus="true" role="button" style="height: 24px;"> 	 			<span id="button4" class="x-btn-inner" style="">Bulk Approval</span> 	 			<span id="button5" class="x-btn-icon "></span> 	 		</button> 	 	</em> 	 </div>');

    jQuery('body').append('<div id="ogrooModel" class="modalbox ogroobox"> 	 	<div class="dialog"> 	 			 		<div  style="min-height: 100px;"> <div class="panel-heading tooltip-wrapper container-fluid" style="border: 1px solid #ddd;padding: 8px;"><h3>Bulk Approve Request</h3></div>			<table id="item_table"> 	 				<thead> 	 					<tr> 	 						<th style="text-align: left"><input type="checkbox" class="all" onclick="selectAll(this)"/><b>&nbsp; </th> 	 						<th style="text-align: left">ID</th> 	 						<th style="text-align: left">Requestee</th> 	 						<th style="text-align: left">Requester</th> 	 						<th style="text-align: left">Requested For</th> 	 						<th style="text-align: left">Application</th> 	 						<th style="text-align: left">Requested On</th> 	 					</tr> 	 				</thead> 	 			</table> 	 			<div style="padding: 8px;"><button  style="float: left;" id="close" onClick="overlay()" tabindex="50" role="button" aria-live="polite" type="button" class="btn btn-s-sm ng-binding ng-scope btn-white "  ng-click="button.actionFunc()" ng-disabled="button.disabledFunc()">Cancel</button>	 				<span class="btn-group-xs-only"><button style="float: right;" id="reject"  aria-pressed="false" class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" > <i class="fa fa-thumbs-down text-danger"  role="presentation"></i>Deny All</button></span><span class="btn-group-xs-only" style="padding: 15px;height: 10px;bottom: 100px;left: 100px; "><button id="approve"    aria-pressed="false"  class="btn btn-sm btn-white ng-binding" role="button" type="button" tabindex="50" aria-hidden="false" style="float: right;"><i class="fa fa-thumbs-up text-success"  role="presentation"></i>Approve All</button></span> </div>	 			 		</div> 	 	</div> 	 </div>');
	document.getElementById("Overly").addEventListener("click", function(){
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display = 'block';
		});
		document.getElementById("close").addEventListener("click", function(){
			var e =document.getElementsByClassName("modalbox");
			e[0].style.display= 'none';
		});
		var xhttp = new XMLHttpRequest();
		xhttp.open("GET", "/identityiq/plugin/rest/test/items", true);
		xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
		xhttp.setRequestHeader('Content-Type', 'application/json');
		xhttp.send();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				obj = JSON.parse(this.responseText);
				//console.log(obj[0]);
				var html = '<tbody style="background-color:##E5E8E8">';
				for (var i=0; i<obj.length; i++) {
					console.log(obj[i]);
					html += '<tr class="post">';
					html += '<td><input class="check" type="checkbox" name="check'+i+'" value="'+obj[i].Name+'" onclick="selectOne(this)"/></td>';
					html +=	'<td>' + obj[i].Name + '</td>';
					html +=	'<td>' + obj[i].Requestee + '</td>';
					html += '<td>' + obj[i].Requester + '</td>';
					html +=	'<td>' + obj[i].Operation + '</td>';
					html += '<td>' + obj[i].Application + '</td>';
					html += '<td>' + obj[i].Created + '</td>';
					
						
					html += "</tr>";
				}
				html += '</tbody>';
				jQuery(html).appendTo('#item_table');
			}
		}
	//}); 

	
	
		jQuery("#approve").click(function(){
			
			var result={};
			jQuery.each(jQuery("input[class='check']:checked"), function(){ 
			result[jQuery(this).val()]=jQuery(this).val();
				//favorite.push(jQuery(this).val());
				console.log(index+result[index]);
			});
				var xhttp = new XMLHttpRequest();
				xhttp.open("POST", "/identityiq/plugin/rest/test/approval", true);
				xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
				xhttp.setRequestHeader('Content-Type', 'application/json');
				//xhttp.send(JSON.stringify({ "id": "0000000219", "response": { "name": "Tester" } }));
				xhttp.send(JSON.stringify(result));
				xhttp.onreadystatechange = function()
				{
					if (this.readyState == 4 && this.status == 200) {
						console.log(this.responseText);
						obj = this.responseText;
						console.log(obj);
					}
				}
		});
	}, 1000); 
});

